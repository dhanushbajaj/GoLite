# Golite Example
  The program is "lexically" correct
  and should not generate any error #
func main() {
    fmt.Print("Hello world!")
}